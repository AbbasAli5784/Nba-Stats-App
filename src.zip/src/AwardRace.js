import React from "react";

const AwardRace = () => {
  return (
    <div>
      <h2>Award Race</h2>
      <p>This is the Award Race page where details of major NBA award standings will be displayed.</p>
    </div>
  );
};

export default AwardRace;
