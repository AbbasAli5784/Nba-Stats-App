import React from "react";

const PlayerProfile = () => {
  return (
    <div>
      <h2>Player Profile</h2>
      <p>This is the Player Profile page where player stats and bios will be shown.</p>
    </div>
  );
};

export default PlayerProfile;
