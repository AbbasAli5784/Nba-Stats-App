import React from "react";

const BoxScore = () => {
  return (
    <div>
      <h2>Box Score</h2>
      <p>This is the Box Score page where detailed game statistics will be displayed.</p>
    </div>
  );
};

export default BoxScore;
