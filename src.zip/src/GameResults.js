import React from "react";

const GameResults = () => {
  return (
    <div>
      <h2>Game Results</h2>
      <p>This is the Game Results page where game summaries and scores will be shown.</p>
    </div>
  );
};

export default GameResults;
