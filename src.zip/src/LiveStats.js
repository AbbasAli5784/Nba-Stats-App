import React from "react";

const LiveStats = () => {
  return (
    <div>
      <h2>Live Stats</h2>
      <p>This is the Live Stats page.</p>
    </div>
  );
};

export default LiveStats;
