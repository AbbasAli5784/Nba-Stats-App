import React from "react";

const Leaderboard = () => {
  return (
    <div>
      <h2>Leaderboard</h2>
      <p>This is the Leaderboard page where top player rankings will be displayed.</p>
    </div>
  );
};

export default Leaderboard;
